"use client"

interface LoginPageProps {
  onLogin: (type: "user" | "admin") => void
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-400 to-blue-200 p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Title */}
        <div className="text-center space-y-4">
          <h1
            className="text-3xl font-bold pixel-text"
            style={{ color: "#e74c3c", textShadow: "3px 3px 0 rgba(0,0,0,0.3)" }}
          >
            TIME
          </h1>
          <h1
            className="text-3xl font-bold pixel-text"
            style={{ color: "#3498db", textShadow: "3px 3px 0 rgba(0,0,0,0.3)" }}
          >
            PREDICTOR
          </h1>
        </div>

        {/* Main Panel */}
        <div className="nes-panel space-y-6">
          <div className="text-center">
            <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
              SELECT MODE
            </p>
          </div>

          {/* User Button */}
          <button
            onClick={() => onLogin("user")}
            className="nes-button w-full text-white secondary"
            style={{
              fontSize: "10px",
              padding: "12px",
            }}
          >
            👤 USER
          </button>

          {/* Admin Button */}
          <button
            onClick={() => onLogin("admin")}
            className="nes-button w-full text-white"
            style={{
              fontSize: "10px",
              padding: "12px",
            }}
          >
            ⚙️ ADMIN
          </button>
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
            ⭐ PRESS START ⭐
          </p>
        </div>
      </div>
    </div>
  )
}
