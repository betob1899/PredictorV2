"use client"

import { useState } from "react"
import LoginPage from "@/components/pages/login-page"
import UserDashboard from "@/components/pages/user-dashboard"
import AdminDashboard from "@/components/pages/admin-dashboard"
import WinnerScreen from "@/components/pages/winner-screen"

export default function Home() {
  const [currentPage, setCurrentPage] = useState<"login" | "user" | "admin" | "winner">("login")
  const [userType, setUserType] = useState<"user" | "admin" | null>(null)

  const handleLogin = (type: "user" | "admin") => {
    setUserType(type)
    if (type === "user") {
      setCurrentPage("user")
    } else {
      setCurrentPage("admin")
    }
  }

  const handleLogout = () => {
    setCurrentPage("login")
    setUserType(null)
  }

  const handleShowWinner = () => {
    setCurrentPage("winner")
  }

  return (
    <main className="min-h-screen bg-blue-200">
      {currentPage === "login" && <LoginPage onLogin={handleLogin} />}
      {currentPage === "user" && <UserDashboard onLogout={handleLogout} />}
      {currentPage === "admin" && <AdminDashboard onLogout={handleLogout} onShowWinner={handleShowWinner} />}
      {currentPage === "winner" && <WinnerScreen onBack={() => setCurrentPage("admin")} />}
    </main>
  )
}
