"use client"

import { useState } from "react"

interface AdminDashboardProps {
  onLogout: () => void
  onShowWinner: () => void
}

export default function AdminDashboard({ onLogout, onShowWinner }: AdminDashboardProps) {
  const [startTime, setStartTime] = useState("")
  const [endTime, setEndTime] = useState("")
  const [sessionName, setSessionName] = useState("")
  const [sessions, setSessions] = useState<Array<{ name: string; start: string; end: string; elapsed: string }>>([])
  const [activeTab, setActiveTab] = useState<"manage" | "sessions" | "predictions">("manage")

  const calculateElapsed = (start: string, end: string) => {
    if (!start || !end) return "00:00"
    const [startH, startM] = start.split(":").map(Number)
    const [endH, endM] = end.split(":").map(Number)
    const startMins = startH * 60 + startM
    const endMins = endH * 60 + endM
    const diff = Math.abs(endMins - startMins)
    const hours = Math.floor(diff / 60)
    const mins = diff % 60
    return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`
  }

  const handleCreateSession = () => {
    if (sessionName && startTime && endTime) {
      const elapsed = calculateElapsed(startTime, endTime)
      setSessions([...sessions, { name: sessionName, start: startTime, end: endTime, elapsed }])
      setSessionName("")
      setStartTime("")
      setEndTime("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-400 to-red-300 p-4">
      {/* Header */}
      <div className="nes-header mb-6 text-center" style={{ backgroundColor: "#e74c3c" }}>
        <h1 className="text-lg pixel-text">⚙️ ADMIN PANEL ⚙️</h1>
      </div>

      <div className="max-w-2xl mx-auto">
        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 flex-wrap justify-center">
          <button
            onClick={() => setActiveTab("manage")}
            className="nes-button text-white text-xs"
            style={{
              backgroundColor: activeTab === "manage" ? "#e74c3c" : "#95a5a6",
              padding: "8px 12px",
            }}
          >
            MANAGE
          </button>
          <button
            onClick={() => setActiveTab("sessions")}
            className="nes-button text-white text-xs"
            style={{
              backgroundColor: activeTab === "sessions" ? "#e74c3c" : "#95a5a6",
              padding: "8px 12px",
            }}
          >
            SESSIONS
          </button>
          <button
            onClick={() => setActiveTab("predictions")}
            className="nes-button text-white text-xs"
            style={{
              backgroundColor: activeTab === "predictions" ? "#e74c3c" : "#95a5a6",
              padding: "8px 12px",
            }}
          >
            PREDICTIONS
          </button>
        </div>

        {/* Manage Tab */}
        {activeTab === "manage" && (
          <div className="nes-panel space-y-4 mb-6">
            <h2 className="text-sm pixel-text" style={{ color: "#1a1a1a", marginBottom: "16px" }}>
              CREATE SESSION
            </h2>

            <div>
              <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                SESSION NAME
              </label>
              <input
                type="text"
                value={sessionName}
                onChange={(e) => setSessionName(e.target.value)}
                maxLength={20}
                className="nes-input"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  START TIME
                </label>
                <input
                  type="text"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  placeholder="HH:MM"
                  maxLength={5}
                  className="nes-input"
                />
              </div>
              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  END TIME
                </label>
                <input
                  type="text"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  placeholder="HH:MM"
                  maxLength={5}
                  className="nes-input"
                />
              </div>
            </div>

            <button
              onClick={handleCreateSession}
              className="nes-button w-full text-white success"
              style={{
                fontSize: "10px",
                padding: "10px",
              }}
            >
              ✓ CREATE
            </button>
          </div>
        )}

        {/* Sessions Tab */}
        {activeTab === "sessions" && (
          <div className="nes-panel space-y-4 mb-6">
            <h2 className="text-sm pixel-text" style={{ color: "#1a1a1a", marginBottom: "16px" }}>
              ACTIVE SESSIONS
            </h2>
            {sessions.length === 0 ? (
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                NO SESSIONS YET
              </p>
            ) : (
              <div className="space-y-2">
                {sessions.map((session, idx) => (
                  <div
                    key={idx}
                    className="border-2 p-2"
                    style={{ borderColor: "#1a1a1a", backgroundColor: "#e0e0e0" }}
                  >
                    <p className="text-xs pixel-text font-bold">{session.name}</p>
                    <p className="text-xs pixel-text">
                      {session.start} → {session.end}
                    </p>
                    <p className="text-xs pixel-text" style={{ color: "#27ae60" }}>
                      ELAPSED: {session.elapsed}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Predictions Tab */}
        {activeTab === "predictions" && (
          <div className="nes-panel space-y-4 mb-6">
            <h2 className="text-sm pixel-text" style={{ color: "#1a1a1a", marginBottom: "16px" }}>
              USER PREDICTIONS
            </h2>
            <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
              📊 SAMPLE PREDICTIONS:
            </p>
            <div className="space-y-2 text-xs pixel-text" style={{ color: "#1a1a1a" }}>
              <div className="border-2 p-2" style={{ borderColor: "#1a1a1a", backgroundColor: "#ffe0e0" }}>
                MARIO LUIGI - AREA: CASTLE - TIME: 01:30 🔴
              </div>
              <div className="border-2 p-2" style={{ borderColor: "#1a1a1a", backgroundColor: "#e0e0ff" }}>
                PEACH TOAD - AREA: MUSHROOM - TIME: 01:45 🔵
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={onShowWinner}
            className="nes-button w-full text-white"
            style={{
              backgroundColor: "#f1c40f",
              color: "#1a1a1a",
              fontSize: "10px",
              padding: "12px",
            }}
          >
            🏆 SHOW WINNER
          </button>

          <button
            onClick={onLogout}
            className="nes-button w-full text-white"
            style={{
              backgroundColor: "#95a5a6",
              fontSize: "10px",
              padding: "12px",
            }}
          >
            ← LOGOUT
          </button>
        </div>
      </div>
    </div>
  )
}
