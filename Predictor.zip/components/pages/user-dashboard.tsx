"use client"

import { useState } from "react"

interface UserDashboardProps {
  onLogout: () => void
}

export default function UserDashboard({ onLogout }: UserDashboardProps) {
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [area, setArea] = useState("")
  const [time, setTime] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = () => {
    if (firstName && lastName && area && time) {
      setSubmitted(true)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-200 p-4">
      {/* Header */}
      <div className="nes-header mb-6 text-center">
        <h1 className="text-lg pixel-text">🎮 USER PREDICTION 🎮</h1>
      </div>

      <div className="max-w-md mx-auto space-y-4">
        {!submitted ? (
          <>
            {/* Form Panel */}
            <div className="nes-panel space-y-4">
              <h2 className="text-sm pixel-text" style={{ color: "#1a1a1a" }}>
                ENTER YOUR INFO
              </h2>

              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  FIRST NAME
                </label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  maxLength={20}
                  className="nes-input"
                />
              </div>

              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  LAST NAME
                </label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  maxLength={20}
                  className="nes-input"
                />
              </div>

              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  AREA
                </label>
                <input
                  type="text"
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  maxLength={20}
                  className="nes-input"
                />
              </div>

              <div>
                <label className="block text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
                  TIME PREDICTION (HH:MM)
                </label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="00:00"
                  maxLength={5}
                  className="nes-input"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleSubmit}
                className="nes-button w-full text-white success"
                style={{
                  fontSize: "10px",
                  padding: "12px",
                }}
              >
                ✓ SUBMIT
              </button>

              <button
                onClick={onLogout}
                className="nes-button w-full text-white"
                style={{
                  backgroundColor: "#95a5a6",
                  fontSize: "10px",
                  padding: "12px",
                }}
              >
                ← LOGOUT
              </button>
            </div>
          </>
        ) : (
          <>
            {/* Success Panel */}
            <div className="nes-panel text-center space-y-4">
              <h2 className="text-sm pixel-text" style={{ color: "#27ae60" }}>
                PREDICTION SAVED!
              </h2>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                NAME: {firstName} {lastName}
              </p>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                AREA: {area}
              </p>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                TIME: {time}
              </p>
              <p className="text-lg pixel-text" style={{ color: "#3498db", marginTop: "16px" }}>
                ⭐ THANK YOU ⭐
              </p>
            </div>

            <button
              onClick={onLogout}
              className="nes-button w-full text-white"
              style={{
                backgroundColor: "#95a5a6",
                fontSize: "10px",
                padding: "12px",
              }}
            >
              ← LOGOUT
            </button>
          </>
        )}
      </div>
    </div>
  )
}
