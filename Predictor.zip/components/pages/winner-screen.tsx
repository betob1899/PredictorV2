"use client"

interface WinnerScreenProps {
  onBack: () => void
}

export default function WinnerScreen({ onBack }: WinnerScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-300 to-yellow-200 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Celebration */}
        <div className="text-center space-y-4">
          <div className="text-6xl mb-4 animate-bounce">🏆</div>
          <h1
            className="text-2xl font-bold pixel-text"
            style={{ color: "#f1c40f", textShadow: "4px 4px 0 rgba(0,0,0,0.3)" }}
          >
            YOU WIN!
          </h1>
        </div>

        {/* Winner Info Panel */}
        <div className="nes-panel text-center space-y-4">
          <h2 className="text-sm pixel-text" style={{ color: "#e74c3c" }}>
            🌟 CONGRATULATIONS 🌟
          </h2>

          <div className="border-2 p-4" style={{ borderColor: "#1a1a1a", backgroundColor: "#ffe0e0" }}>
            <p className="text-xs pixel-text" style={{ color: "#1a1a1a", marginBottom: "8px" }}>
              WINNER
            </p>
            <p className="text-sm pixel-text font-bold" style={{ color: "#e74c3c" }}>
              MARIO LUIGI
            </p>
          </div>

          <div className="space-y-2">
            <div className="border-2 p-2" style={{ borderColor: "#1a1a1a", backgroundColor: "#cccccc" }}>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                ACTUAL TIME
              </p>
              <p className="text-sm pixel-text font-bold" style={{ color: "#3498db" }}>
                01:30:00
              </p>
            </div>

            <div className="border-2 p-2" style={{ borderColor: "#1a1a1a", backgroundColor: "#cccccc" }}>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                PREDICTION
              </p>
              <p className="text-sm pixel-text font-bold" style={{ color: "#27ae60" }}>
                01:30:15
              </p>
            </div>

            <div className="border-2 p-2" style={{ borderColor: "#1a1a1a", backgroundColor: "#e0ffe0" }}>
              <p className="text-xs pixel-text" style={{ color: "#1a1a1a" }}>
                DIFFERENCE
              </p>
              <p className="text-sm pixel-text font-bold" style={{ color: "#27ae60" }}>
                +15 SEC
              </p>
            </div>
          </div>

          <p className="text-xs pixel-text" style={{ color: "#1a1a1a", marginTop: "16px" }}>
            ⭐ CLOSEST GUESS ⭐
          </p>
        </div>

        {/* Back Button */}
        <button
          onClick={onBack}
          className="nes-button w-full text-white secondary"
          style={{
            fontSize: "10px",
            padding: "12px",
          }}
        >
          ← BACK TO ADMIN
        </button>
      </div>
    </div>
  )
}
